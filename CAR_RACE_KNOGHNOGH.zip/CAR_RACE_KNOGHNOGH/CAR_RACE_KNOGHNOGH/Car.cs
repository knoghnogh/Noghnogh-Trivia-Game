﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace CAR_RACE_KNOGHNOGH
{
    public class Car
    {
        public string Name; 
        public string color;

        public Car() { }
        public Car(string PassInname, string PassIncolor)
        {
            Name = PassInname;
            color = PassIncolor;
        }


        public void About()
        {

            Console.WriteLine(Name + " which is color #" + color + ".");

        }
    }
}


