﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;


namespace CAR_RACE_KNOGHNOGH
{
    public class Game
    {
        public int Goal;
        private string Name;

        //constructor
        public Game()
        {
            Title = "Car Demo";
            WriteLine("Welcome " + Player.Name + " player. Enter your name:");
            Player.Name = ReadLine();
            BackgroundColor = ConsoleColor.White;
            ForegroundColor = ConsoleColor.DarkCyan;
            Clear();
            Play();
        }


        //method

        public void Play()
        {
            WriteLine("Cars and their Color.");
            Car Toyota = new Car();
            Toyota.Name = "Toyota Celica";
            Toyota.color = "blue";
            WriteLine(Player.Name + ", The first car we have is " + Toyota.Name + "which is color #" + Toyota.color + ".");

            Car Mazda = new Car("Mazda", "black");
            Mazda.About();

            Car Dodge = new Car("Dodge", "Gold");
            Dodge.About();

            ReadKey();
            //Toyota Celica blue
            //Mazda RX-7 black
            //Dodge Charger Gold

        }

    }
}