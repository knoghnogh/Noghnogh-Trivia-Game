﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CAR_RACE_KNOGHNOGH
{
    class Player
    {
       //public int Name;
       //public int Gender;
        
            public static string Name = "Anonymous";
            int score = 0;

        public Player()
        {
            throw new System.NotImplementedException();
        }
    }
}